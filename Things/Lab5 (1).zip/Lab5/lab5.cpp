/*
    ICS 51, Lab #5

    --------------------------------------------------------------------
 
    IMPORTATNT NOTES:
    
    - To test your code use the tests in lab5-tester.cpp
    
    - Write your assembly code only in the marked areas.
    
    - You are not allowed to change anything in this file except for adding your assembly code 
    between the lines marked with "YOUR CODE STARTS HERE" and "YOUR CODE ENDS HERE".

    - This lab has to be done individually.

    - Remember to fill in your name, student ID number and UCInetID below.

    - A test image is provided to you (lion.png).
    
    - ONLY submit your completed lab5.cpp for grading.
*/

const char *yourName = "Your name here";
const char *yourStudentID = "Your student ID number here";
const char *yourUCInetID = "Your UCInetID here";

#define RANDOMIZE_CALLEE_REGISTERS __asm mov ebx, 0xAFAFAFAF \
                                   __asm mov esi, 0xAFAFAFAF \
                                   __asm mov edi, 0xAFAFAFAF 
#define RANDOMIZE_CALLER_REGISTERS __asm mov eax, 0xAFAFAFAF \
                                   __asm mov ecx, 0xAFAFAFAF \
                                   __asm mov edx, 0xAFAFAFAF

/***********************************************************************************************

    PART 1: Image Rotation

    - This function rotates a square sized color image 90 degress clockwise.
    - The width and height of the image are both equal to dim.
    - Four variables (a0, a90, a180, a270) are defined that you may use in your implementation for
    temporary data storage. You are not allowed to define additional variables.

************************************************************************************************/
void imageRotation(unsigned int* image, int dim, int n) {
    unsigned int a0, a90, a180, a270;
    __asm 
    {
        // YOUR CODE STARTS HERE
		
        // YOUR CODE ENDS HERE
    }
}

/***********************************************************************************************

PART 2: Selection Sort

Selection sort is an in-place comparison sort algorithm that works by dividing the input list
into two parts: the sublist of items already sorted, which is built up from left to right of
the list, and the sublist of items remaining to be sorted that occupy the rest of the list.
Initially, the sorted sublist is empty and the unsorted sublist is the entire input list.
The algorithm proceeds by finding the smallest element in the unsorted sublist, exchanging it
with the leftmost unsorted element (putting it in sorted order), and moving the sublist
boundaries one element to the right. To learn more, read:
https://en.wikipedia.org/wiki/Selection_sort#Example

Our implementation here uses a function called "findMinIndex" to find the index of smallest
element between ith index and jth index of the array. The function "selectionSort" uses
this function to find the smallest number and exchanges it with the leftmost unsorted element
in each iteration. You need to implement the behavior of both functions in x86 assembly.

************************************************************************************************/
__declspec(naked)
int findMinIndex(int integer_array[], int i, int j)
{

	// C code to be converted to x86 assembly
	/*
	int iMin = i;
	// test against elements after i and before j to find the smallest
	for ( i ; i < j; i++) {
	// if this element is less, then it is the new minimum
	if (integer_array[i] < integer_array[iMin]) {
	// found new minimum; remember its index
	iMin = i;
	}
	}

	return iMin;
	*/

	RANDOMIZE_CALLER_REGISTERS

		__asm
	{
		// YOUR CODE STARTS HERE

		// YOUR CODE ENDS HERE
		ret
	}

}

void selectionSort(int integer_array[], int array_size)
{

	// C code to be converted to x86 assembly
	/*
	int j;
	int iMin;
	int temp;

	// advance the position through the entire array //
	// (could do j < n-1 because single element is also min element) //
	for (j = 0; j < array_size-1; j++) {

	// find the index of min element in the unsorted a[j .. n-1] //
	iMin = findMinIndex (integer_array, j, array_size);

	if(iMin != j) { // swap values
	temp = integer_array[iMin];
	integer_array[iMin] = integer_array [j];
	integer_array[j] = temp;
	}
	}
	*/

	RANDOMIZE_CALLEE_REGISTERS
	RANDOMIZE_CALLER_REGISTERS

		__asm
	{
		// YOUR CODE STARTS HERE
		
		// YOUR CODE ENDS HERE
	}

}